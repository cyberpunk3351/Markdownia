
- смотри у меня есть сервис изучи его и дай мне понятное описание что он делает
Шаг за шагом

- I want you to translate from English into Russian. I will paste the text, and you will translate it. Please also take the context into account. The text is from Reddit. Thank you.