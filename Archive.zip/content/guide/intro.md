# Getting Started

This guide shows how nested directories appear in the file tree.

```bash
npm install
npm run dev
```

Look for **keywords** like search or intro to test the search feature.
