# Welcome

This is a sample document stored in the backend content directory. Update this text to see live reloads in the app.

- Markdown files must live inside the `content/` folder.
- The backend indexes only `.md` files.
- Try editing this file while the dev server runs to see auto-refresh.
