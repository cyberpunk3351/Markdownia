<template>
  <div class="min-h-screen bg-surface text-gray-100">
    <router-view />
  </div>
</template>

<script setup>
</script>
